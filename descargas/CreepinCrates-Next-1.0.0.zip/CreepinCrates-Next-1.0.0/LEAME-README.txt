CREEPIN' CRATES para / for ZX Spectrum Next
Versión / Version 1.0.0 - noviembre / November 2026
RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Contenido
  CreepinCrates/CRATES.NEX       El juego: la carpeta va a la tarjeta SD tal cual.
  Creepin-Crates-Next-Manual-ES.pdf              Manual en español, para leer en pantalla.
  Creepin-Crates-Next-Manual-ES-imprimir-A4.pdf  El mismo, para imprimir en A4.
  Creepin-Crates-Next-Manual-EN.pdf              Manual en inglés, para leer en pantalla.
  Creepin-Crates-Next-Manual-EN-imprimir-A4.pdf  El mismo, para imprimir en A4.
  LICENCIA-LICENSE.txt           El texto completo de la licencia (en inglés).

Requisitos
  Una ZX Spectrum Next o una compatible (Xberry Pi, N-Go...) con NextZXOS, desde
  el core 3.01.10; alcanza con 1 MB de memoria. Joystick Kempston en cualquier
  puerto, o el teclado.

Cómo cargarlo
  Copia la carpeta CreepinCrates a la tarjeta SD (en cualquier lugar). En el
  navegador de NextZXOS (Browser), entra en la carpeta, elige CRATES.NEX y
  presiona ENTER. O, en la línea de comandos, dentro de la carpeta:
    .nexload CRATES.NEX
  En un emulador: en ZEsarUX, zesarux --machine tbblue --snap CRATES.NEX; en
  CSpect, CSpect.exe -zxnext -mmc=./ CRATES.NEX desde la carpeta.
  Para jugar en Windows o Linux sin configurar nada, baja los paquetes de
  https://ripworx.dev/ (traen ZEsarUX con todo preparado).

Controles
  Caminar: joystick, flechas o W A S D. Empujar o romper la caja de enfrente:
  botón, ESPACIO o 0 (también empieza la partida y saltea las escenas). P pausa,
  M música, E efectos. En el salón de la fama, el nombre se escribe con el
  teclado (DELETE, es decir CAPS SHIFT y 0, borra; ENTER termina) o con el
  joystick.

El salón de la fama se guarda solo en la tarjeta, en CRATES.SAV, en la carpeta
del juego (si se lo abre desde esa carpeta, con el navegador o con .ripsync).
Si no se puede grabar, aparece SAVE FAILED con un número de error, y el juego
sigue.

Creepin' Crates (c) 2026 RIPworx. Licencia Creative Commons BY-NC-ND 4.0: puedes
copiarlo y compartirlo gratis, sin fines comerciales, tal cual y diciendo
quiénes son sus autores (ver LICENCIA-LICENSE.txt). ZX Spectrum Next, ZX
Spectrum y Sinclair son marcas registradas de sus respectivos dueños.

================================================================
ENGLISH
================================================================

Contents
  CreepinCrates/CRATES.NEX       The game: the folder goes on the SD card as it is.
  Creepin-Crates-Next-Manual-EN.pdf              Manual in English, for reading on screen.
  Creepin-Crates-Next-Manual-EN-imprimir-A4.pdf  The same, for printing on A4.
  Creepin-Crates-Next-Manual-ES.pdf              Manual in Spanish, for reading on screen.
  Creepin-Crates-Next-Manual-ES-imprimir-A4.pdf  The same, for printing on A4.
  LICENCIA-LICENSE.txt           The full license text.

Requirements
  A ZX Spectrum Next or a compatible machine (Xberry Pi, N-Go...) with
  NextZXOS, core 3.01.10 or later; 1 MB of memory is enough. A Kempston
  joystick in either port, or the keyboard.

How to load it
  Copy the CreepinCrates folder to the SD card (anywhere). In the NextZXOS
  Browser, go into the folder, choose CRATES.NEX and press ENTER. Or, from the
  command line, inside the folder:
    .nexload CRATES.NEX
  On an emulator: in ZEsarUX, zesarux --machine tbblue --snap CRATES.NEX; in
  CSpect, CSpect.exe -zxnext -mmc=./ CRATES.NEX from the folder.
  To play on Windows or Linux without setting anything up, get the packages
  from https://ripworx.dev/ (they bring ZEsarUX with everything ready).

Controls
  Walk: joystick, arrow keys or W A S D. Push or break the crate in front of
  you: fire button, SPACE or 0 (it also starts the game and skips the scenes).
  P pause, M music, E sound effects. In the Hall of Fame, type your name on the
  keyboard (DELETE, that is CAPS SHIFT and 0, erases; ENTER ends) or with the
  joystick.

The Hall of Fame is saved automatically on the card, in CRATES.SAV, in the
game's folder (when you open it from that folder, with the Browser or with
.ripsync). If it can't be saved, SAVE FAILED appears with an error number, and
the game goes on.

Creepin' Crates (c) 2026 RIPworx. Creative Commons BY-NC-ND 4.0 license: you
may copy and share it for free, for non-commercial purposes, as is and crediting
its authors (see LICENCIA-LICENSE.txt). ZX Spectrum Next, ZX Spectrum and
Sinclair are trademarks of their respective owners.
