POTHOLE RUSH para MEGA65 - Windows / for Windows
Versión / Version 1.0.0 - RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Cómo jugar
  Con el zip: descomprime TODO el zip en una carpeta (por ejemplo en Documentos
  o en el Escritorio) y abre "Pothole Rush" (Pothole Rush.exe). No lo abras
  desde adentro del zip. No hace falta instalar nada: para quitarlo, borra la
  carpeta.
  Con el autodescomprimible (...-setup.exe): queda todo en la carpeta que
  elegiste, con un acceso directo "Pothole Rush MEGA65" en el escritorio. Para
  quitarlo, borra la carpeta y el acceso directo.
  Con el instalador (...-x64.msi): el juego queda en el menú Inicio y en el
  escritorio ("Pothole Rush MEGA65"); se desinstala desde Configuración >
  Aplicaciones.
  Con el portátil (...-x64-portable.exe): guárdalo donde quieras (también en
  un pendrive) y ábrelo con doble clic. Descomprime el juego en una carpeta
  temporal de Windows y la borra al cerrarlo: no deja nada más que el avance.

  La primera vez, Windows puede mostrar "Windows protegió su PC" (SmartScreen),
  porque el programa no tiene firma digital. Haz clic en "Más información" y
  después en "Ejecutar de todas formas".

  El juego corre en Xemu, un emulador de la MEGA65, sin la ROM de la MEGA65
  (no se puede distribuir): un cargador propio arranca el juego directamente.

Controles
  Mover                     W A S D, las flechas, o el gamepad (palanca o cruceta)
  Saltar (con un salto)     Espacio, o cualquier botón del gamepad
  Pausa                     P (el salto también la saca)
  Radio: prender / apagar   M (solo la música; los efectos, en OPTIONS)
  Radio: tema siguiente     T
  Abandonar la partida      ESC (pregunta CANCEL? Y/N; lo jugado cuenta)
  Menús: elegir             Espacio, RETURN, o cualquier botón del gamepad
  Menús: volver             ESC, o la tecla ← (arriba a la izquierda, junto al 1)
  Pantalla completa         F11
  Salir                     F9, o cerrar la ventana
  Gamepad: conéctalo ANTES de abrir el juego. Todos los gamepads juegan juntos,
  como un joystick en el puerto 2.
  El manual completo está en https://ripworx.dev/.

Tu avance
  El dinero, el récord, las compras, las medallas, el salón de la fama, las
  opciones y el tema de la radio se guardan solos en el disco del juego
  (emulador\potholerush.d81).
  Con el zip: para pasar tu avance a una versión nueva, copia el
  emulador\potholerush.d81 de la carpeta vieja a la nueva (reemplazando el que
  trae). Si quieres empezar de cero, vuelve a descomprimir el zip.
  Con el autodescomprimible: elige la misma carpeta de antes; el disco con tu
  avance se conserva.
  Con el instalador (.msi) y con el portátil: el disco con tu avance va
  aparte, en %APPDATA%\RIPworx\Pothole Rush MEGA65, y los dos usan el mismo:
  juegues con uno o con el otro, el avance es el mismo. Se conserva con las
  versiones nuevas, y desinstalar no lo borra (para empezar de cero, borra esa
  carpeta). No abras los dos a la vez: el último que guarda pisa lo del otro.

Qué trae
  Pothole Rush.exe       Abre el juego.
  emulador\              El emulador Xemu (MEGA65), el juego (cargador.m65 y
                         atico.bin) y el disco donde se guarda el avance.
  licencias\             Las licencias de cada parte y dónde está su código
                         fuente.

Para jugarlo en una MEGA65 de verdad, baja el zip de la MEGA65 de
https://ripworx.dev/.

Pothole Rush (c) 2026 RIPworx. Licencia Creative Commons BY-NC-ND 4.0: puedes
copiarlo y compartirlo gratis, sin fines comerciales, tal cual y diciendo
quiénes son sus autores (licencias\PotholeRush-CC-BY-NC-ND-4.0.txt).

================================================================
ENGLISH
================================================================

How to play
  With the zip: extract the WHOLE zip to a folder (for example, Documents or
  the Desktop) and open "Pothole Rush" (Pothole Rush.exe). Don't open it from
  inside the zip. Nothing to install: to remove it, delete the folder.
  With the self-extractor (...-setup.exe): everything goes to the folder you
  chose, with a "Pothole Rush MEGA65" shortcut on the desktop. To remove it,
  delete the folder and the shortcut.
  With the installer (...-x64.msi): the game is in the Start menu and on the
  desktop ("Pothole Rush MEGA65"); uninstall it from Settings > Apps.
  With the portable one (...-x64-portable.exe): keep it anywhere (a USB stick
  too) and double-click it. It unpacks the game to a temporary Windows folder
  and deletes it when you close the game: it leaves nothing but your progress.

  The first time, Windows may show "Windows protected your PC" (SmartScreen),
  because the program is not digitally signed. Click "More info" and then
  "Run anyway".

  The game runs in Xemu, a MEGA65 emulator, without the MEGA65 ROM (it can't be
  distributed): a small loader of our own starts the game directly.

Controls
  Move                      W A S D, the arrow keys, or the gamepad (stick or d-pad)
  Jump (if you have one)    Space, or any gamepad button
  Pause                     P (jumping also resumes)
  Radio on / off            M (music only; sound effects in OPTIONS)
  Radio: next track         T
  Quit the run              ESC (asks CANCEL? Y/N; what you played counts)
  Menus: choose             Space, RETURN, or any gamepad button
  Menus: back               ESC, or the ← key (top left, next to 1)
  Full screen               F11
  Quit                      F9, or close the window
  Gamepad: plug it in BEFORE opening the game. All gamepads play together, as a
  joystick in port 2.
  The full manual is at https://ripworx.dev/.

Your progress
  Your money, record, purchases, medals, Hall of Fame, options and radio track
  are saved automatically on the game disk (emulador\potholerush.d81).
  With the zip: to carry your progress to a new version, copy
  emulador\potholerush.d81 from the old folder to the new one (replacing the
  one it comes with). To start over, extract the zip again.
  With the self-extractor: choose the same folder as before; the disk with
  your progress is kept.
  With the installer (.msi) and the portable one: the disk with your progress
  is kept apart, in %APPDATA%\RIPworx\Pothole Rush MEGA65, and both use the
  same one: whichever you play, your progress is the same. It stays with new
  versions, and uninstalling doesn't delete it (to start over, delete that
  folder). Don't open both at once: the last one to save overwrites the other.

What's inside
  Pothole Rush.exe       Opens the game.
  emulador\              The Xemu emulator (MEGA65), the game (cargador.m65 and
                         atico.bin) and the disk where your progress is saved.
  licencias\             The license of each part and where its source code is.

To play it on a real MEGA65, get the MEGA65 zip from https://ripworx.dev/.

Pothole Rush (c) 2026 RIPworx. Creative Commons BY-NC-ND 4.0 license: you may
copy and share it for free, for non-commercial purposes, as is and crediting
its authors (licencias\PotholeRush-CC-BY-NC-ND-4.0.txt).
