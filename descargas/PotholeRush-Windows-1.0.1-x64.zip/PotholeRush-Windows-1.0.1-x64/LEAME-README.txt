POTHOLE RUSH para Windows / for Windows
Versión / Version 1.0.1 - RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Cómo jugar
  1. Descomprime TODO el zip en una carpeta (por ejemplo en Documentos o en el
     Escritorio). No lo abras desde adentro del zip.
  2. Abre "Pothole Rush" (Pothole Rush.exe).
  No hace falta instalar nada. Para desinstalarlo, borra la carpeta.
  Si usaste el autodescomprimible (...-setup.exe), ya está todo en la carpeta
  que elegiste y hay un acceso directo "Pothole Rush" en el escritorio: para
  quitarlo, borra la carpeta y el acceso directo.
  Si usaste el instalador (...-x64.msi), el juego está en el menú Inicio y en
  el escritorio; se desinstala desde Configuración > Aplicaciones.

  La primera vez, Windows puede mostrar "Windows protegió su PC" (SmartScreen),
  porque el programa no tiene firma digital. Haz clic en "Más información" y
  después en "Ejecutar de todas formas".

Controles
  Teclado: cursores o W A S D para moverse, espacio para saltar (y RETURN en los
  menús). Siempre funciona, haya o no un gamepad.
  Gamepads: conéctalos ANTES de abrir el juego. El primero que encuentre Windows
  queda como el joystick del puerto 2 y el segundo, como el del puerto 1 (el
  juego lee los dos). Palanca izquierda o cruceta para moverse; cualquiera de
  los cuatro botones principales, para saltar.
  Alt+Enter (o Alt+D): pantalla completa / ventana.
  F12: el menú del emulador (VICE). Alt+Q: salir.

Tu avance
  El dinero, el récord, las compras, las medallas, el salón de la fama y las
  opciones se guardan solos dentro del archivo potholerush.crt (el cartucho),
  cuando cierras la ventana. Si quieres empezar de cero, vuelve a descomprimir
  el zip. Si la carpeta no se puede escribir (por ejemplo, dentro de "Archivos
  de programa"), no se guarda nada.
  Para pasar tu avance a una versión nueva: con el autodescomprimible
  (...-setup.exe), elige la misma carpeta de antes y se pasa solo. Con el zip,
  copia el potholerush.crt de la carpeta vieja a la nueva con el nombre
  potholerush-pasar.crt y abre el juego. En los dos casos el cartucho viejo
  queda como potholerush-anterior.crt, por las dudas.
  Con el instalador (.msi), el avance se guarda aparte, en
  %APPDATA%\RIPworx\Pothole Rush: al instalar una versión nueva del juego se
  conserva (la primera vez que lo abres se pasa al cartucho nuevo; el anterior
  queda como potholerush-anterior.crt), y desinstalar no lo borra.

Qué trae
  Pothole Rush.exe       Abre el juego.
  potholerush.crt        El juego: un cartucho EasyFlash de la Commodore 64,
                         preparado para las ROM libres (también funciona en una
                         C64 real). Para la C64, mejor el zip de la C64 en
                         https://ripworx.dev/.
  vice\                  El emulador VICE 3.10 (versión SDL2) con las ROM libres
                         de la C64 del proyecto MEGA65 (Open ROMs).
  licencias\             Las licencias de cada parte y dónde está su código
                         fuente.

Pothole Rush fue creado por Sebas Zayas en Scratch
(https://scratch.mit.edu/projects/24184856/).
Llevado a la Commodore 64 por Carlos Zayas, con la ayuda de Claude, de Anthropic.

Licencias
  El juego (potholerush.crt, este texto y el lanzador "Pothole Rush.exe"): puedes
  copiarlo y compartirlo gratis y sin fines comerciales, siempre que lo pases tal
  cual (sin modificarlo) y digas quiénes son sus autores. Licencia Creative
  Commons Atribución-NoComercial-SinDerivadas 4.0 Internacional (CC BY-NC-ND 4.0).
  El cartucho lleva EAPI, de Thomas Giesel (licencia zlib).
  El emulador y sus bibliotecas tienen sus propias licencias, en la carpeta
  licencias\: VICE (GPL 2.0), Open ROMs (LGPL 3.0), SDL2 y SDL2_image (zlib),
  zlib, libpng y winpthreads.

================================================================
ENGLISH
================================================================

How to play
  1. Extract the WHOLE zip to a folder (for example in Documents or on the
     Desktop). Don't open it from inside the zip.
  2. Open "Pothole Rush" (Pothole Rush.exe).
  Nothing to install. To uninstall, delete the folder.
  If you used the self-extractor (...-setup.exe), everything is already in the
  folder you chose and there is a "Pothole Rush" shortcut on the desktop: to
  remove it, delete the folder and the shortcut.
  If you used the installer (...-x64.msi), the game is in the Start menu and on
  the desktop; uninstall it from Settings > Apps.

  The first time, Windows may show "Windows protected your PC" (SmartScreen),
  because the program isn't digitally signed. Click "More info" and then
  "Run anyway".

Controls
  Keyboard: cursor keys or W A S D to move, space to jump (and RETURN in the
  menus). It always works, with or without a gamepad.
  Gamepads: plug them in BEFORE opening the game. The first one Windows finds
  becomes the joystick in port 2 and the second one, the joystick in port 1 (the
  game reads both). Left stick or D-pad to move; any of the four main buttons
  to jump.
  Alt+Enter (or Alt+D): full screen / window.
  F12: the emulator (VICE) menu. Alt+Q: quit.

Your progress
  Money, record, purchases, medals, Hall of Fame and options are saved
  automatically inside the file potholerush.crt (the cartridge) when you close
  the window. To start over, extract the zip again. If the folder can't be
  written to (for example, inside "Program Files"), nothing is saved.
  To move your progress to a new version: with the self-extractor
  (...-setup.exe), choose the same folder as before and it is moved by itself.
  With the zip, copy potholerush.crt from the old folder to the new one, named
  potholerush-pasar.crt, and open the game. Either way the old cartridge is
  kept as potholerush-anterior.crt, just in case.
  With the installer (.msi), your progress is kept apart, in
  %APPDATA%\RIPworx\Pothole Rush: it survives installing a new version of the
  game (the first time you open it, it is moved to the new cartridge; the old
  one is kept as potholerush-anterior.crt), and uninstalling doesn't delete it.

What's inside
  Pothole Rush.exe       Opens the game.
  potholerush.crt        The game: a Commodore 64 EasyFlash cartridge, prepared
                         for the free ROMs (it also works on a real C64). For
                         the C64, better use the C64 zip at
                         https://ripworx.dev/.
  vice\                  The VICE 3.10 emulator (SDL2 version) with the free C64
                         ROMs from the MEGA65 project (Open ROMs).
  licencias\             The license of each part and where its source code is.

Pothole Rush was created by Sebas Zayas in Scratch
(https://scratch.mit.edu/projects/24184856/).
Brought to the Commodore 64 by Carlos Zayas, with the help of Claude, by Anthropic.

Licenses
  The game (potholerush.crt, this text and the launcher "Pothole Rush.exe"): you
  may copy and share it free of charge and for non-commercial purposes, as long
  as you pass it on as is (unmodified) and credit its authors. Creative Commons
  Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0).
  The cartridge includes EAPI, by Thomas Giesel (zlib license).
  The emulator and its libraries have their own licenses, in the licencias\
  folder: VICE (GPL 2.0), Open ROMs (LGPL 3.0), SDL2 and SDL2_image (zlib),
  zlib, libpng and winpthreads.

----------------------------------------------------------------
(c) 2026 RIPworx. Hecho en Paraguay / Made in Paraguay.
Commodore 64 es una marca registrada de su respectivo dueño /
Commodore 64 is a trademark of its respective owner.
