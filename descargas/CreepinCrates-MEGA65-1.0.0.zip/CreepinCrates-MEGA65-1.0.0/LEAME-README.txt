CREEPIN' CRATES para / for MEGA65 (PAL, NTSC)
Versión / Version 1.0.0 - noviembre / November 2026
RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Probado en una MEGA65 real: ¡gracias, Tayger! Si lo juegas en la tuya (sobre
todo con otra revisión de placa o en NTSC), cuéntanos cómo anda: en el Filehost
de MEGA65 o por Discord, a czayas.

Contenido
  creepincrates-1.0.0.d81        Imagen de disco: el juego, los dibujos, la música
                                 y el salón de la fama (CC.FAME).
  Creepin-Crates-MEGA65-Manual-ES.pdf              Manual en español, para leer en pantalla.
  Creepin-Crates-MEGA65-Manual-ES-imprimir-A4.pdf  El mismo, para imprimir en A4.
  Creepin-Crates-MEGA65-Manual-EN.pdf              Manual en inglés, para leer en pantalla.
  Creepin-Crates-MEGA65-Manual-EN-imprimir-A4.pdf  El mismo, para imprimir en A4.
  LICENCIA-LICENSE.txt           El texto completo de la licencia (en inglés).

Requisitos
  Una MEGA65 con los 8 MB de RAM del ático (todas las placas: R3, R3A, R6), PAL
  o NTSC, o el emulador Xemu con la ROM de la MEGA65. Joystick en cualquier
  puerto, o el teclado.

Cómo cargarlo
  En la MEGA65: copia el .d81 a la tarjeta SD y móntalo como unidad 8 (desde el
  menú del Freezer: mantén apretada RESTORE un momento). Después, en BASIC 65:
    RUN "CREEPINCRATES"
  En Xemu: xmega65 -8 creepincrates-1.0.0.d81 (o monta el .d81 desde el menú
  de Xemu) y después RUN "CREEPINCRATES".
  Si el borde se pone rojo, algo falló (por ejemplo, no está la RAM del ático
  o falta un archivo del disco): avísanos con la revisión de tu placa y la
  versión del core.
  Para jugar en Windows o Linux sin la ROM, baja los paquetes de
  https://ripworx.dev/ (traen Xemu con todo preparado).

Controles
  Caminar: joystick, flechas o W A S D. Empujar o romper la caja de enfrente:
  botón o ESPACIO (también empieza la partida y saltea las escenas). P pausa,
  M música, E efectos. En el salón de la fama, el nombre se escribe con el
  teclado (INST/DEL borra, RETURN termina) o con el joystick.

El salón de la fama se guarda solo en el disco, en el archivo CC.FAME: tiene que
ser el .d81 en la tarjeta SD (o en Xemu), en la unidad 8, y sin protección
contra escritura. Si no se puede grabar, aparece SAVE FAILED y el juego sigue.

Creepin' Crates (c) 2026 RIPworx. Licencia Creative Commons BY-NC-ND 4.0: puedes
copiarlo y compartirlo gratis, sin fines comerciales, tal cual y diciendo
quiénes son sus autores (ver LICENCIA-LICENSE.txt).

================================================================
ENGLISH
================================================================

Tested on a real MEGA65: thanks, Tayger! If you play it on yours (especially on
another board revision or in NTSC), please tell us how it goes: on the MEGA65
Filehost, or on Discord, to czayas.

Contents
  creepincrates-1.0.0.d81        Disk image: the game, the graphics, the music and
                                 the Hall of Fame (CC.FAME).
  Creepin-Crates-MEGA65-Manual-EN.pdf              Manual in English, for reading on screen.
  Creepin-Crates-MEGA65-Manual-EN-imprimir-A4.pdf  The same, for printing on A4.
  Creepin-Crates-MEGA65-Manual-ES.pdf              Manual in Spanish, for reading on screen.
  Creepin-Crates-MEGA65-Manual-ES-imprimir-A4.pdf  The same, for printing on A4.
  LICENCIA-LICENSE.txt           The full license text.

Requirements
  A MEGA65 with the 8 MB of attic RAM (every board: R3, R3A, R6), PAL or NTSC, or
  the Xemu emulator with the MEGA65 ROM. A joystick in either port, or the
  keyboard.

How to load it
  On the MEGA65: copy the .d81 to the SD card and mount it as drive 8 (from the
  Freezer menu: hold RESTORE for a moment). Then, in BASIC 65:
    RUN "CREEPINCRATES"
  On Xemu: xmega65 -8 creepincrates-1.0.0.d81 (or mount the .d81 from the Xemu
  menu), then RUN "CREEPINCRATES".
  If the border turns red, something went wrong (for example, there's no attic
  RAM or a file is missing from the disk): tell us your board revision
  and core version.
  To play on Windows or Linux without the ROM, get the packages from
  https://ripworx.dev/ (they bring Xemu with everything set up).

Controls
  Walk: joystick, arrow keys or W A S D. Push or break the crate in front of
  you: fire button or SPACE (it also starts the game and skips the scenes).
  P pause, M music, E sound effects. In the Hall of Fame, type your name on the
  keyboard (INST/DEL deletes, RETURN ends) or with the joystick.

The Hall of Fame is saved automatically on the disk, in the file CC.FAME: it has
to be the .d81 on the SD card (or in Xemu), in drive 8, not write-protected. If
it can't be saved, SAVE FAILED appears and the game goes on.

Creepin' Crates (c) 2026 RIPworx. Creative Commons BY-NC-ND 4.0 license: you
may copy and share it for free, for non-commercial purposes, as is and crediting
its authors (see LICENCIA-LICENSE.txt).
