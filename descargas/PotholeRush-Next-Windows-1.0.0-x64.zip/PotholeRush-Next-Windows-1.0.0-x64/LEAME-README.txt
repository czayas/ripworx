POTHOLE RUSH para ZX Spectrum Next - Windows / for Windows
Versión / Version 1.0.0 - RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Cómo jugar
  Con el zip: descomprime TODO el zip en una carpeta (por ejemplo en Documentos
  o en el Escritorio) y abre "Pothole Rush" (Pothole Rush.exe). No lo abras
  desde adentro del zip. No hace falta instalar nada: para quitarlo, borra la
  carpeta.
  Con el autodescomprimible (...-setup.exe): queda todo en la carpeta que
  elegiste, con un acceso directo "Pothole Rush ZX Spectrum Next" en el
  escritorio. Para quitarlo, borra la carpeta y el acceso directo.
  Con el instalador (...-x64.msi): el juego queda en el menú Inicio y en el
  escritorio ("Pothole Rush ZX Spectrum Next"); se desinstala desde
  Configuración > Aplicaciones.
  Con el portátil (...-x64-portable.exe): guárdalo donde quieras (también en
  un pendrive) y ábrelo con doble clic. Descomprime el emulador en una carpeta
  temporal de Windows y la borra al cerrarlo: no deja nada más que el avance.

  La primera vez, Windows puede mostrar "Windows protegió su PC" (SmartScreen),
  porque el programa no tiene firma digital. Haz clic en "Más información" y
  después en "Ejecutar de todas formas".

  El juego corre en ZEsarUX, un emulador de la ZX Spectrum Next, sin la ROM
  del Spectrum (no se puede distribuir, y el juego no la usa): en su lugar va
  una ROM vacía propia.

Controles
  Arriba / abajo            W / S, las flechas, o el gamepad (palanca o cruceta)
  Frenar / acelerar         A / D, las flechas, o el gamepad
  Saltar (con un salto)     Espacio, o los botones A, B, X, Y del gamepad
  Pausa                     P, o el botón Start del gamepad
  Radio: prender / apagar   M (solo la música; los efectos, en OPTIONS)
  Radio: tema siguiente     T
  Abandonar la partida      ESC (es la tecla BREAK de la Next: pregunta
                            CANCEL? [Y] N; lo jugado cuenta)
  Menús: elegir             Espacio, ENTER, o un botón del gamepad
  Menús: volver             ESC
  Pantalla completa         F11
  Menú del emulador         F5
  Salir                     cerrar la ventana
  Gamepad: conéctalo ANTES de abrir el juego. Juega el primero que encuentre
  Windows, como un joystick Kempston.
  El manual completo está en https://ripworx.dev/.

Tu avance
  El dinero, el récord, las compras, las medallas, el salón de la fama, las
  opciones y el tema de la radio se guardan solos en el archivo POTHOLE.SAV,
  que el juego crea la primera vez que guarda.
  Con el zip y con el autodescomprimible: POTHOLE.SAV queda en la carpeta
  emulador. Para pasar tu avance a una versión nueva del zip, copia
  emulador\POTHOLE.SAV de la carpeta vieja a la nueva; con el
  autodescomprimible, elige la misma carpeta de antes y se conserva. Para
  empezar de cero, borra POTHOLE.SAV.
  Con el instalador (.msi) y con el portátil: el avance va aparte, en
  %APPDATA%\RIPworx\Pothole Rush Next, y los dos usan el mismo: juegues con uno
  o con el otro, el avance es el mismo. Se conserva con las versiones nuevas,
  y desinstalar no lo borra (para empezar de cero, borra esa carpeta). No
  abras los dos a la vez: el último que guarda pisa lo del otro.
  POTHOLE.SAV es el mismo archivo que usa la ZX Spectrum Next de verdad (y la
  MEGA65): lo puedes copiar a la tarjeta SD, al lado de POTHOLE.NEX, y seguir
  jugando ahí.

Qué trae
  Pothole Rush.exe       Abre el juego.
  emulador\              El emulador ZEsarUX, la ROM vacía y el juego
                         (potholerush.nex).
  licencias\             Las licencias de cada parte y dónde está su código
                         fuente.

Para jugarlo en una ZX Spectrum Next de verdad (o una Xberry Pi), baja el zip
de la ZX Spectrum Next de https://ripworx.dev/.

Pothole Rush (c) 2026 RIPworx. Licencia Creative Commons BY-NC-ND 4.0: puedes
copiarlo y compartirlo gratis, sin fines comerciales, tal cual y diciendo
quiénes son sus autores (licencias\PotholeRush-CC-BY-NC-ND-4.0.txt).

================================================================
ENGLISH
================================================================

How to play
  With the zip: extract the WHOLE zip to a folder (for example, Documents or
  the Desktop) and open "Pothole Rush" (Pothole Rush.exe). Don't open it from
  inside the zip. Nothing to install: to remove it, delete the folder.
  With the self-extractor (...-setup.exe): everything goes to the folder you
  chose, with a "Pothole Rush ZX Spectrum Next" shortcut on the desktop. To
  remove it, delete the folder and the shortcut.
  With the installer (...-x64.msi): the game is in the Start menu and on the
  desktop ("Pothole Rush ZX Spectrum Next"); uninstall it from Settings >
  Apps.
  With the portable one (...-x64-portable.exe): keep it anywhere (a USB stick
  too) and double-click it. It unpacks the emulator to a temporary Windows
  folder and deletes it when you close the game: it leaves nothing but your
  progress.

  The first time, Windows may show "Windows protected your PC" (SmartScreen),
  because the program is not digitally signed. Click "More info" and then
  "Run anyway".

  The game runs in ZEsarUX, a ZX Spectrum Next emulator, without the Spectrum
  ROM (it can't be distributed, and the game doesn't use it): an empty ROM of
  our own takes its place.

Controls
  Up / down                 W / S, the arrow keys, or the gamepad (stick or d-pad)
  Brake / speed up          A / D, the arrow keys, or the gamepad
  Jump (if you have one)    Space, or gamepad buttons A, B, X, Y
  Pause                     P, or the gamepad Start button
  Radio on / off            M (music only; sound effects in OPTIONS)
  Radio: next track         T
  Quit the run              ESC (the Next's BREAK key: asks CANCEL? [Y] N;
                            what you played counts)
  Menus: choose             Space, ENTER, or a gamepad button
  Menus: back               ESC
  Full screen               F11
  Emulator menu             F5
  Quit                      close the window
  Gamepad: plug it in BEFORE opening the game. The first one Windows finds
  plays, as a Kempston joystick.
  The full manual is at https://ripworx.dev/.

Your progress
  Your money, record, purchases, medals, Hall of Fame, options and radio track
  are saved automatically in POTHOLE.SAV, which the game creates the first
  time it saves.
  With the zip and the self-extractor: POTHOLE.SAV is in the emulador folder.
  To carry your progress to a new version of the zip, copy
  emulador\POTHOLE.SAV from the old folder to the new one; with the
  self-extractor, choose the same folder as before and it is kept. To start
  over, delete POTHOLE.SAV.
  With the installer (.msi) and the portable one: your progress is kept apart,
  in %APPDATA%\RIPworx\Pothole Rush Next, and both use the same one: whichever
  you play, your progress is the same. It stays with new versions, and
  uninstalling doesn't delete it (to start over, delete that folder). Don't
  open both at once: the last one to save overwrites the other.
  POTHOLE.SAV is the same file the real ZX Spectrum Next (and the MEGA65)
  uses: you can copy it to the SD card, next to POTHOLE.NEX, and keep playing
  there.

What's inside
  Pothole Rush.exe       Opens the game.
  emulador\              The ZEsarUX emulator, the empty ROM and the game
                         (potholerush.nex).
  licencias\             The license of each part and where its source code is.

To play it on a real ZX Spectrum Next (or an Xberry Pi), get the ZX Spectrum
Next zip from https://ripworx.dev/.

Pothole Rush (c) 2026 RIPworx. Creative Commons BY-NC-ND 4.0 license: you may
copy and share it for free, for non-commercial purposes, as is and crediting
its authors (licencias\PotholeRush-CC-BY-NC-ND-4.0.txt).
