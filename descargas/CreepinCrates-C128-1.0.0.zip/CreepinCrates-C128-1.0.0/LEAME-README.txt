CREEPIN' CRATES para / for Commodore 128 (80 columnas / 80 columns)
Versión / Version 1.0.0 - noviembre / November 2026
RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

AVISO: en el emulador VICE el juego anda bien, pero en una Commodore 128 real
todavía no se ve como debe (aparecen barras en la pantalla). Estamos buscando
la causa. Si lo pruebas en la máquina, cuéntanos cómo se ve: por Discord, a
czayas.

Contenido
  creepincrates-1.0.0.d64        Imagen de disco: el juego, los dibujos, la música
                                 y el salón de la fama (CC.FAME).
  Creepin-Crates-Manual-ES.pdf              Manual en español, para leer en pantalla.
  Creepin-Crates-Manual-ES-imprimir-A4.pdf  El mismo, para imprimir en A4.
  Creepin-Crates-Manual-EN.pdf              Manual en inglés, para leer en pantalla.
  Creepin-Crates-Manual-EN-imprimir-A4.pdf  El mismo, para imprimir en A4.
  LICENCIA-LICENSE.txt           El texto completo de la licencia (en inglés).

Requisitos
  Una Commodore 128 con el chip de video VDC de 64 KB (el de la C128D de chapa,
  o uno ampliado; la C128 y la C128D de plástico traen 16 KB, y con esos el
  juego avisa y no arranca) y un monitor de 80 columnas (RGBI). Una disquetera
  1571 o 1541, o una SD2IEC, Pi1541 o Ultimate. Joystick en cualquier puerto, o
  el teclado. O el emulador VICE (x128) con el VDC de 64 KB.

Cómo cargarlo
  En el modo 128, en 80 columnas:
    RUN"CREEPIN' CRATES"
  (el apóstrofo es SHIFT+7). Con una 1571 tarda unos 8 segundos en cargar; con
  una 1541, alrededor de medio minuto.
  En VICE: x128 -80col -VDC64KB -autostart creepincrates-1.0.0.d64

Controles
  Caminar: joystick, flechas o W A S D. Empujar o romper la caja de enfrente:
  botón o ESPACIO (también empieza la partida y saltea las escenas). P pausa,
  M música, E efectos. En el salón de la fama, el nombre se escribe con el
  teclado (INST/DEL borra, RETURN termina) o con el joystick.

El salón de la fama se guarda solo en el disco, en el archivo CC.FAME. Si no se
puede grabar (disco protegido, sin disquetera), aparece SAVE FAILED y el juego
sigue.

Creepin' Crates (c) 2026 RIPworx. Licencia Creative Commons BY-NC-ND 4.0: puedes
copiarlo y compartirlo gratis, sin fines comerciales, tal cual y diciendo
quiénes son sus autores (ver LICENCIA-LICENSE.txt).

================================================================
ENGLISH
================================================================

NOTE: the game works fine in the VICE emulator, but on a real Commodore 128 it
doesn't look right yet (bars show up on the screen). We are looking for the
cause. If you try it on the machine, please tell us how it looks: on Discord,
to czayas.

Contents
  creepincrates-1.0.0.d64        Disk image: the game, the graphics, the music and
                                 the Hall of Fame (CC.FAME).
  Creepin-Crates-Manual-EN.pdf              Manual in English, for reading on screen.
  Creepin-Crates-Manual-EN-imprimir-A4.pdf  The same, for printing on A4.
  Creepin-Crates-Manual-ES.pdf              Manual in Spanish, for reading on screen.
  Creepin-Crates-Manual-ES-imprimir-A4.pdf  The same, for printing on A4.
  LICENCIA-LICENSE.txt           The full license text.

Requirements
  A Commodore 128 with the 64 KB VDC video chip (the one in the metal C128D, or
  an upgraded one; the C128 and the plastic C128D come with 16 KB, and with that
  the game tells you so and won't start) and an 80-column (RGBI) monitor. A 1571
  or 1541 disk drive, or an SD2IEC, Pi1541 or Ultimate. A joystick in either
  port, or the keyboard. Or the VICE emulator (x128) with the 64 KB VDC.

How to load it
  In 128 mode, on the 80-column screen:
    RUN"CREEPIN' CRATES"
  (the apostrophe is SHIFT+7). It takes about 8 seconds to load with a 1571,
  and about half a minute with a 1541.
  On VICE: x128 -80col -VDC64KB -autostart creepincrates-1.0.0.d64

Controls
  Walk: joystick, arrow keys or W A S D. Push or break the crate in front of
  you: fire button or SPACE (it also starts the game and skips the scenes).
  P pause, M music, E sound effects. In the Hall of Fame, type your name on the
  keyboard (INST/DEL deletes, RETURN ends) or with the joystick.

The Hall of Fame is saved automatically on the disk, in the file CC.FAME. If it
can't be saved (write-protected disk, no drive), SAVE FAILED appears and the
game goes on.

Creepin' Crates (c) 2026 RIPworx. Creative Commons BY-NC-ND 4.0 license: you
may copy and share it for free, for non-commercial purposes, as is and crediting
its authors (see LICENCIA-LICENSE.txt).
