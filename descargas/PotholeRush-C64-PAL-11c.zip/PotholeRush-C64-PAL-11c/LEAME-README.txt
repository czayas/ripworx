POTHOLE RUSH para / for Commodore 64 (PAL)
Versión de prueba / Test version 11c - octubre / October 2026
RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Contenido
  potholerush-11c-pal.d64    Imagen de disco: presentación, pantalla de carga y el
                             juego. Es la versión recomendada.
  potholerush-11c-pal.prg    El juego solo, sin presentación (para cargar directo
                             desde una SD2IEC, una Ultimate, un emulador, etc.).
  PotholeRush-Manual-ES.pdf  Manual de instrucciones en español.
  PotholeRush-Manual-EN.pdf  Manual de instrucciones en inglés.
  LICENCIA-LICENSE.txt       El texto completo de la licencia (en inglés).

Requisitos
  Una Commodore 64 PAL y una disquetera (o un equivalente: SD2IEC, Pi1541,
  Ultimate, Kung Fu Flash...). Joystick en cualquier puerto, o el teclado.
  Esta versión es solo PAL: en una máquina NTSC el juego corre más rápido.
  Las versiones NTSC y en cartucho (CRT) llegan más adelante.

Cómo cargarlo
  Disco: LOAD"*",8 y después RUN.
  Emulador (por ejemplo VICE): elige un modelo PAL y abre el archivo .d64.

El avance (dinero, récord, compras, medallas, salón de la fama y opciones) se
guarda solo en el disco, en el archivo POTHOLE.SAV. No protejas el disco contra
escritura. Más detalles en el manual.

Pothole Rush fue creado por Sebas Zayas en Scratch
(https://scratch.mit.edu/projects/24184856/).
Llevado a la Commodore 64 por Carlos Zayas, con la ayuda de Claude, de Anthropic.

Licencia
  Puedes copiar y compartir este zip y todo lo que trae, gratis y sin fines
  comerciales, siempre que lo pases tal cual (sin modificarlo) y digas quiénes
  son sus autores. Licencia Creative Commons Atribución-NoComercial-SinDerivadas
  4.0 Internacional (CC BY-NC-ND 4.0):
  https://creativecommons.org/licenses/by-nc-nd/4.0/deed.es

================================================================
ENGLISH
================================================================

Contents
  potholerush-11c-pal.d64    Disk image: presentation, loading screen and the
                             game. This is the recommended version.
  potholerush-11c-pal.prg    The game alone, without the presentation (to load
                             directly from an SD2IEC, an Ultimate, an emulator...).
  PotholeRush-Manual-EN.pdf  Instruction manual in English.
  PotholeRush-Manual-ES.pdf  Instruction manual in Spanish.
  LICENCIA-LICENSE.txt       The full text of the license.

Requirements
  A PAL Commodore 64 and a disk drive (or an equivalent: SD2IEC, Pi1541,
  Ultimate, Kung Fu Flash...). A joystick in either port, or the keyboard.
  This version is PAL only: on an NTSC machine the game runs too fast.
  NTSC and cartridge (CRT) versions are coming later.

How to load it
  Disk: LOAD"*",8 then RUN.
  Emulator (for example VICE): choose a PAL model and open the .d64 file.

Your progress (money, record, purchases, medals, Hall of Fame and options) is
saved automatically on the disk, in the file POTHOLE.SAV. Don't write-protect
the disk. More details in the manual.

Pothole Rush was created by Sebas Zayas in Scratch
(https://scratch.mit.edu/projects/24184856/).
Brought to the Commodore 64 by Carlos Zayas, with the help of Claude, by Anthropic.

License
  You may copy and share this zip and everything in it, free of charge and for
  non-commercial purposes, as long as you pass it on as is (unmodified) and
  credit its authors. Creative Commons Attribution-NonCommercial-NoDerivatives
  4.0 International (CC BY-NC-ND 4.0):
  https://creativecommons.org/licenses/by-nc-nd/4.0/

----------------------------------------------------------------
(c) 2026 RIPworx. CC BY-NC-ND 4.0. Hecho en Paraguay / Made in Paraguay.
Commodore 64 es una marca registrada de su respectivo dueño /
Commodore 64 is a trademark of its respective owner.
