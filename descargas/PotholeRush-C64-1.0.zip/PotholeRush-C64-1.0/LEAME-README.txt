POTHOLE RUSH para / for Commodore 64 (PAL, NTSC, Drean)
Versión / Version 1.0 - octubre / October 2026
RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Contenido
  potholerush-1.0.d64        Imagen de disco: presentación, pantalla de carga y
                                 el juego.
  potholerush-1.0.crt        Cartucho EasyFlash: el mismo juego, que arranca solo
                                 al prender la máquina y guarda en el propio cartucho.
  potholerush-1.0.prg        El juego solo, sin presentación (para cargar directo
                                 desde una SD2IEC, una Ultimate, un emulador, etc.).
  PotholeRush-Manual-ES.pdf      Manual de instrucciones en español.
  PotholeRush-Manual-EN.pdf      Manual de instrucciones en inglés.
  LICENCIA-LICENSE.txt           El texto completo de la licencia (en inglés).

Requisitos
  Una Commodore 64 (PAL, NTSC o Drean: el juego reconoce solo cuál es) y una
  disquetera (o un equivalente: SD2IEC, Pi1541, Ultimate, Kung Fu Flash...), o
  un cartucho EasyFlash 3 o una Ultimate para el .crt. Joystick en cualquier
  puerto, o el teclado.

Cómo cargarlo
  Disco: LOAD"*",8 y después RUN.
  Cartucho, en un EasyFlash 3: graba el .crt en el cartucho con EasyProg
    ("Write CRT to flash") y prende la máquina.
  Cartucho, en una Ultimate (1541 Ultimate II+ o Ultimate 64): elige el .crt en
    el navegador de archivos ("Run Cart").
  Emulador (por ejemplo VICE): cualquier modelo de C64; abre el .d64, o el .crt
    como cartucho EasyFlash (File > Attach cartridge image).

El avance (dinero, récord, compras, medallas, salón de la fama y opciones) se
guarda solo:
  - En el disco, en el archivo POTHOLE.SAV. No protejas el disco contra escritura.
  - En el cartucho, en su propia memoria. En la Ultimate, antes de apagar,
    guárdalo en el .crt desde su menú (F5 > C64 Machine > Save Cartridge,
    según el firmware). En
    VICE, usa una copia del .crt: VICE escribe en él lo guardado al cerrarse.
    Si vuelves a grabar el .crt en un EasyFlash 3, se borra el avance.
Más detalles en el manual.

Pothole Rush fue creado por Sebas Zayas en Scratch
(https://scratch.mit.edu/projects/24184856/).
Llevado a la Commodore 64 por Carlos Zayas, con la ayuda de Claude, de Anthropic.

Licencia
  Puedes copiar y compartir este zip y todo lo que trae, gratis y sin fines
  comerciales, siempre que lo pases tal cual (sin modificarlo) y digas quiénes
  son sus autores. Licencia Creative Commons Atribución-NoComercial-SinDerivadas
  4.0 Internacional (CC BY-NC-ND 4.0):
  https://creativecommons.org/licenses/by-nc-nd/4.0/deed.es
  El cartucho lleva EAPI, de Thomas Giesel (licencia zlib), el programa con el
  que el EasyFlash graba en su propia memoria.

================================================================
ENGLISH
================================================================

Contents
  potholerush-1.0.d64        Disk image: presentation, loading screen and the
                                 game.
  potholerush-1.0.crt        EasyFlash cartridge: the same game, which starts on
                                 its own at power-on and saves on the cartridge itself.
  potholerush-1.0.prg        The game alone, without the presentation (to load
                                 directly from an SD2IEC, an Ultimate, an emulator...).
  PotholeRush-Manual-EN.pdf      Instruction manual in English.
  PotholeRush-Manual-ES.pdf      Instruction manual in Spanish.
  LICENCIA-LICENSE.txt           The full text of the license.

Requirements
  A Commodore 64 (PAL, NTSC or Drean: the game works out which one by itself)
  and a disk drive (or an equivalent: SD2IEC, Pi1541, Ultimate, Kung Fu
  Flash...), or an EasyFlash 3 cartridge or an Ultimate for the .crt. A
  joystick in either port, or the keyboard.

How to load it
  Disk: LOAD"*",8 then RUN.
  Cartridge, on an EasyFlash 3: write the .crt to the cartridge with EasyProg
    ("Write CRT to flash") and turn the machine on.
  Cartridge, on an Ultimate (1541 Ultimate II+ or Ultimate 64): choose the .crt
    in the file browser ("Run Cart").
  Emulator (for example VICE): any C64 model; open the .d64, or attach the .crt
    as an EasyFlash cartridge (File > Attach cartridge image).

Your progress (money, record, purchases, medals, Hall of Fame and options) is
saved automatically:
  - On the disk, in the file POTHOLE.SAV. Don't write-protect the disk.
  - On the cartridge, in its own memory. On the Ultimate, before turning it
    off, save it to the .crt from its menu (F5 > C64 Machine > Save Cartridge,
    depending on the firmware).
    In VICE, use a copy of the .crt: VICE writes your progress into it when it
    closes. Writing the .crt to an EasyFlash 3 again erases your progress.
More details in the manual.

Pothole Rush was created by Sebas Zayas in Scratch
(https://scratch.mit.edu/projects/24184856/).
Brought to the Commodore 64 by Carlos Zayas, with the help of Claude, by Anthropic.

License
  You may copy and share this zip and everything in it, free of charge and for
  non-commercial purposes, as long as you pass it on as is (unmodified) and
  credit its authors. Creative Commons Attribution-NonCommercial-NoDerivatives
  4.0 International (CC BY-NC-ND 4.0):
  https://creativecommons.org/licenses/by-nc-nd/4.0/
  The cartridge includes EAPI, by Thomas Giesel (zlib license), the program the
  EasyFlash uses to write to its own memory.

----------------------------------------------------------------
(c) 2026 RIPworx. CC BY-NC-ND 4.0. Hecho en Paraguay / Made in Paraguay.
Commodore 64 es una marca registrada de su respectivo dueño /
Commodore 64 is a trademark of its respective owner.
