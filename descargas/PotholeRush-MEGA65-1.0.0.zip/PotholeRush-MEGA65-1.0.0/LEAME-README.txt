POTHOLE RUSH para / for MEGA65 (PAL, NTSC)
Versión / Version 1.0.0 - octubre / October 2026
RIPworx - https://ripworx.dev/

================================================================
ESPAÑOL
================================================================

Contenido
  potholerush-1.0.0.d81          Imagen de disco: los menús, el juego, los gráficos
                                 y el archivo donde se guarda el avance (POTHOLE.SAV).
  PotholeRush-MEGA65-Manual-ES.pdf   Manual de instrucciones en español.
  PotholeRush-MEGA65-Manual-EN.pdf   Manual de instrucciones en inglés.
  LICENCIA-LICENSE.txt           El texto completo de la licencia (en inglés).

Requisitos
  Una MEGA65 (o el emulador Xemu con la ROM de la MEGA65), PAL o NTSC. Joystick
  en cualquier puerto, o el teclado.

Cómo cargarlo
  En la MEGA65: copia el .d81 a la tarjeta SD y móntalo como unidad 8 (desde el
  menú del Freezer: mantén apretada RESTORE un momento). Después, en BASIC 65:
    RUN "POTHOLE"
  En Xemu: xmega65 -8 potholerush-1.0.0.d81 (o monta el .d81 desde el menú
  de Xemu) y después RUN "POTHOLE".
  Tarda un par de segundos en cargar. Para salir, reinicia la máquina.
  Para jugar en Windows o Linux sin la ROM, baja los paquetes de
  https://ripworx.dev/ (traen Xemu con todo preparado).

El avance (dinero, récord, compras, medallas, salón de la fama, opciones y tema
de la radio) se guarda solo en el disco, en el archivo POTHOLE.SAV: tiene que
ser el .d81 en la tarjeta SD (o en Xemu), en la unidad 8, y sin protección
contra escritura. En una disquetera de verdad no se puede guardar (aparece
SAVE FAILED).

Pothole Rush (c) 2026 RIPworx. Licencia Creative Commons BY-NC-ND 4.0: puedes
copiarlo y compartirlo gratis, sin fines comerciales, tal cual y diciendo
quiénes son sus autores (ver LICENCIA-LICENSE.txt).

================================================================
ENGLISH
================================================================

Contents
  potholerush-1.0.0.d81          Disk image: the menus, the game, the graphics and
                                 the file where your progress is saved (POTHOLE.SAV).
  PotholeRush-MEGA65-Manual-ES.pdf   Instruction manual in Spanish.
  PotholeRush-MEGA65-Manual-EN.pdf   Instruction manual in English.
  LICENCIA-LICENSE.txt           The full license text.

Requirements
  A MEGA65 (or the Xemu emulator with the MEGA65 ROM), PAL or NTSC. A joystick
  in either port, or the keyboard.

How to load it
  On the MEGA65: copy the .d81 to the SD card and mount it as drive 8 (from the
  Freezer menu: hold RESTORE for a moment). Then, in BASIC 65:
    RUN "POTHOLE"
  On Xemu: xmega65 -8 potholerush-1.0.0.d81 (or mount the .d81 from the Xemu
  menu), then RUN "POTHOLE".
  It takes a couple of seconds to load. To quit, reset the machine.
  To play on Windows or Linux without the ROM, get the packages from
  https://ripworx.dev/ (they bring Xemu with everything set up).

Your progress (money, record, purchases, medals, Hall of Fame, options and radio
track) is saved automatically on the disk, in the file POTHOLE.SAV: it has to be
the .d81 on the SD card (or in Xemu), in drive 8, not write-protected. It can't
be saved on a real floppy drive (SAVE FAILED appears).

Pothole Rush (c) 2026 RIPworx. Creative Commons BY-NC-ND 4.0 license: you may
copy and share it for free, for non-commercial purposes, as is and crediting
its authors (see LICENCIA-LICENSE.txt).
