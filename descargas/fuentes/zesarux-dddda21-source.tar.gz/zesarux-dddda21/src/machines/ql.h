/*
    ZEsarUX  ZX Second-Emulator And Released for UniX
    Copyright (C) 2013 Cesar Hernandez Bano

    This file is part of ZEsarUX.

    ZEsarUX is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef QL_H
#define QL_H

//Para no hacer include de cpu.h, que provoca errores de compilacion por registros iguales en core de z80 y motorola (como reg_b)
//estos dos solo necesarios temporalmente para funciones legacy, como peek_byte_no_time_legacy_ql por ejemplo
typedef unsigned char z80_byte;
typedef unsigned short z80_int;

//Tipos propios para motorola, para intentar evitar z80_
typedef unsigned char moto_byte; // 8 bits
typedef unsigned short moto_int; // 16 bits
typedef unsigned int moto_long; // 32 bits
typedef unsigned long long moto_long_long; // 64 bits



struct s_moto_bit {
        unsigned int v:1;
};


typedef struct s_moto_bit moto_bit;

extern int ql_total_frames;

extern int ql_cpu_turbo;
extern int ql_extension_cpu_turbo_enabled;
extern void ql_basext_reset(void);
extern void ql_basext_poll(void);

//128kb de ROM + 1920 KB de RAM
#define QL_MAXIMUM_MEM_LIMIT ((1024*2048)-1)

extern unsigned int ql_mem_limit;
extern  unsigned char *memoria_ql;

extern void ql_set_memory_size(int kb_ram);
extern int ql_get_maximum_ram_kb(void);
extern int ql_get_current_ram_kb(void);

extern unsigned char (*ql_readbyte_no_ports_function)(unsigned int Address);
extern unsigned char ql_readbyte_no_ports_vacio(unsigned int Address);


//QL no tiene border como tal. Pero ponemos algo para dejar margen y porque ademas es requisito de ZEsarUX que todas las máquinas tengan border
#define QL_LEFT_BORDER_NO_ZOOM 8
#define QL_TOP_BORDER_NO_ZOOM 8

#define QL_LEFT_BORDER QL_LEFT_BORDER_NO_ZOOM*zoom_x
#define QL_TOP_BORDER QL_TOP_BORDER_NO_ZOOM*zoom_y

//#define QL_LEFT_BORDER 0
//#define QL_TOP_BORDER 0
//Resolucion maxima es 512*256. Para que sea pantalla cuadrada, haremos 512x512 poniendo pixeles doble de alto
#define QL_DISPLAY_WIDTH 512
#define QL_DISPLAY_HEIGHT 512
//Para cumplir proporcion 4:3 -> (512/3)*4=682.66666
#define QL_133_DISPLAY_WIDTH 682
//Proporcion real 1.476
#define QL_1476_DISPLAY_WIDTH 755


#define QL_SIZE_TYPE_1476 0
#define QL_SIZE_TYPE_133 1
#define QL_SIZE_TYPE_1_1 2

extern int ql_pantalla_proporcion_real;
extern int ql_get_display_width_with_proportion(void);

extern void scr_refresca_pantalla_y_border_ql(void);

extern int ql_border_color;

#define m68k_read_memory_8 GetMemB
#define m68k_read_memory_16 GetMemW
#define m68k_read_memory_32 GetMemL

#define m68k_write_memory_8 SetMemB
#define m68k_write_memory_16 SetMemW
#define m68k_write_memory_32 SetMemL



extern unsigned char ql_readbyte_no_ports(unsigned int Address);
extern void ql_writebyte_no_ports(unsigned int Address,unsigned char valor);
extern void ql_writebyte(unsigned int Address, unsigned char Data);
extern unsigned char ql_readbyte(unsigned int Address);


//Funciones legacy solo para interceptar posibles llamadas a poke, peek etc en caso de motorola
//la mayoria de estas vienen del menu, lo ideal es que en el menu se usen peek_byte_z80_moto , etc
extern void poke_byte_legacy_ql(z80_int dir,z80_byte valor);
extern void poke_byte_no_time_legacy_ql(z80_int dir,z80_byte valor);
extern z80_byte peek_byte_legacy_ql(z80_int dir);
extern z80_byte peek_byte_no_time_legacy_ql(z80_int dir);
extern z80_byte lee_puerto_legacy_ql(z80_byte h,z80_byte l);
extern void out_port_legacy_ql(z80_int puerto,z80_byte value);
extern z80_byte fetch_opcode_legacy_ql(void);


extern void motorola_get_flags_string(char *texto);


extern void ql_load_and_execute(char *nombre);
extern void ql_handle_boot_file(char *filename);
extern void ql_expand_mdv_and_boot(char *archivo);
extern void ql_expand_win_and_boot(char *archivo);

extern char ql_nombre_autorun[];

extern int ql_use_visionql_color_palette;

extern int ql_qimi_mouse_enabled;

extern void ql_qimi_reset(void);

extern void ql_qimi_handle_irq(int scanline);

extern int ql_qimi_irq_enabled;

extern unsigned char ql_qimi_movement_register_114620;
extern unsigned char ql_qimi_buttons_register_114588;

extern int ql_qimi_mouse_sensibilidad;

#define QL_QIMI_MOUSE_MAX_SENSIBILITY 10

extern void ql_load_extra_roms(void);

extern int ql_extra_rom_c000_enabled;

extern char ql_extra_rom_c000[];



extern void ql_expand_img_and_boot(char *archivo);

#endif
