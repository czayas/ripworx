;; #LAYOUT# STD *       #TAKE
;; #LAYOUT# X16 BASIC_0 #TAKE-OFFSET 2000
;; #LAYOUT# *   BASIC_0 #TAKE
;; #LAYOUT# *   *       #IGNORE

;
; Official BASIC routine, described in:
;
; - [RG64] C64 Programmers Reference Guide   - XXX
; - [CM64] Computes Mapping the Commodore 64 - page 70, XXX
;
; CPU registers that has to be preserved (see [RG64]): XXX
;


EVAL:

	+STUB_IMPLEMENTATION
